#!/bin/bash

CONFIG_FILE="/root/observer.conf"
LOG_FILE="/root/observer.log"

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') [ERROR] Конфигурационный файл $CONFIG_FILE не найден" >> "$LOG_FILE"
    exit 1
fi

while read -r script_path; do
    [[ -z "$script_path" || "$script_path" =~ ^# ]] && continue

    script_name="$(basename "$script_path")"
    is_running=false

    for pid in $(ls /proc | grep '^[0-9]\+$'); do
        if [[ -r "/proc/$pid/cmdline" ]]; then
            cmdline=$(tr '\0' ' ' < "/proc/$pid/cmdline")
            if echo "$cmdline" | grep -q "$script_name"; then
                is_running=true
                break
            fi
        fi
    done

    if [[ "$is_running" = false ]]; then
        nohup "$script_path" >/dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Перезапущен $script_path" >> "$LOG_FILE"
    fi
done < "$CONFIG_FILE"

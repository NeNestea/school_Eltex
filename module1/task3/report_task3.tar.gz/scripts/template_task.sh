#!/bin/bash

script_name="$(basename "$0")"
report_name="report_${script_name}.log"
pid="$$"
datetime() {
    date '+%Y-%m-%d %H:%M:%S'
}

if [[ "$script_name" == "template_task.sh" ]]; then
    echo "[$pid] $(datetime) я бригадир, сам не работаю"
    exit 1
fi

echo "[$pid] $(datetime) cкрипт работает" >> "$report_name"

sleep_seconds=$(( RANDOM % 1771 + 30 ))

sleep "$sleep_seconds"

worked_minutes=$(( (sleep_seconds + 30) / 60 ))

echo "[$pid] $(datetime) скрипт завершился - $worked_minutes минут" >> "$report_name"
